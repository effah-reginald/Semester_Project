#include <iostream>
#include <windows.h>

using namespace std;

enum TrafficLightColor {
    RED,
   YELLOW,
   GREEN,
    
};

class TrafficLight {
private:
    TrafficLightColor currentColor;

public:
    TrafficLight() : currentColor(RED) {}

    void changeColor() {
        switch (currentColor) {
            case RED:
                currentColor = YELLOW;
                break;
            case YELLOW:
                currentColor = GREEN;
                break;
            case GREEN:
                currentColor = RED;
                break;
        }
    }

    TrafficLightColor getCurrentColor() const {
        return currentColor;
    }
};

void sleep(int seconds) {
    Sleep(seconds * 200);
}

int main() {
    TrafficLight trafficLight;

    while (true) {
        switch (trafficLight.getCurrentColor()) {
            case RED:
                cout << "Red light" << endl;
                sleep(5);
                break;
            case YELLOW:
                cout << "Yellow light" << endl;
                sleep(7);
                break;
            case GREEN:
                cout << "Green light" << endl;
                sleep(2);
                break;
        }

        trafficLight.changeColor();
    }

return 0;
}
